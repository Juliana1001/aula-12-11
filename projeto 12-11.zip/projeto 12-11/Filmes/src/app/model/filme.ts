export class Filme {
    Title: string = ''
    Year: string = ''
    Director: string = ''
    Country: string = ''
    Poster: string = ''
    Genre: string = ''
}