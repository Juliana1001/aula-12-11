import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Filme } from '../model/filme';
import { FilmeService } from '../model/filme.service';

@Component({
  selector: 'app-busca-filmes',
  templateUrl: './busca-filmes.component.html',
  styleUrl: './busca-filmes.component.css'
})
export class BuscaFilmesComponent {
  formBusca: FormGroup 
  filme: Filme | undefined

  constructor(private fb: FormBuilder, private fs: FilmeService){
    this.formBusca = this.fb.group({
      titulo: ['', [Validators.required, Validators.minLength(4)]]
    })
    this.filme = undefined
  }

  buscar(){
    const titulo = this.formBusca.value.titulo
    this.filme = this.fs.buscarFilmePorTitulo(titulo)
  }
}
